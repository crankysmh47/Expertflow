$ErrorActionPreference='Stop'
$widerRepo='C:\sem4\expertflow'
$widerWorkspace=Join-Path $widerRepo '.superpowers\sdd\2026-10-05-wider-stock-collector'
Set-Location -LiteralPath $widerRepo
$widerJob=[ordered]@{status='RUNNING';pid=$PID;started_at_utc=[DateTime]::UtcNow.ToString('o');command='uv run --no-sync python validate_final.py';exit_code=$null}
$widerJob | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $widerWorkspace 'validation-job.json') -Encoding utf8
try {
    & uv run --no-sync python (Join-Path $widerWorkspace 'validate_final.py') *> (Join-Path $widerWorkspace 'validation-wrapper.log')
    $widerJob.exit_code=$LASTEXITCODE
    $widerJob.status='COMPLETED'
} catch {
    $widerJob.status='SUPERVISOR-FAILED'
    $widerJob.reason=$_.Exception.Message
} finally {
    $widerJob.finished_at_utc=[DateTime]::UtcNow.ToString('o')
    $widerJob | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $widerWorkspace 'validation-job.json') -Encoding utf8
}
