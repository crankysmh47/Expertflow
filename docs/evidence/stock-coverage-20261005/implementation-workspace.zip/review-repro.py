import sys,json,uuid
from pathlib import Path
from copy import deepcopy
import pytest
sys.path.insert(0,str(Path.cwd()))
sys.path.insert(0,str(Path('tests').resolve()))
from test_stock_wider import fixture_context
from expertflow.compiler.runner import ServerMeasurementRunner
from expertflow.compiler.evidence import EvidenceStore
from expertflow.compiler.plan import CandidatePlan,RuntimeSettings
from expertflow.compiler import preflight
base=Path('.superpowers/sdd/2026-10-05-wider-stock-collector')/('review-repro-'+uuid.uuid4().hex[:8])
base.mkdir(parents=True)
results={}
with pytest.MonkeyPatch.context() as patch:
    root=base/'positive';root.mkdir()
    ctx=fixture_context(root,patch)
    wider,inp,case,seq,clock,factory,runners,host=ctx
    report=wider.execute_case(inp,case,seq,runner_factory=factory,capture=lambda:deepcopy(host))
    results['positive_status']=report['status']
    altered=deepcopy(report)
    altered['collection_finished_monotonic_ns']=altered['manifest']['case_started_monotonic_ns']
    altered['collection_wall_seconds']=0
    try:
        rebuilt=wider.validate_case(altered,inp,seq,host_environment=host)
        results['forged_zero_collection_cost']={'accepted':True,'collection_wall_seconds':rebuilt['collection_wall_seconds'],'utility_gain_established':rebuilt['utility_gain_established'],'actual_wait_seconds':rebuilt['wait_seconds']}
    except Exception as e:results['forged_zero_collection_cost']={'accepted':False,'reason':str(e)}
print(json.dumps(results),flush=True)
with pytest.MonkeyPatch.context() as patch:
    root=base/'product_failure';root.mkdir()
    ctx=fixture_context(root,patch)
    wider,inp,case,seq,clock,factory,runners,host=ctx
    def fail_product(store):
        runner=factory(store)
        runner.fail=store.path.name=='product.sqlite3'
        return runner
    report=wider.execute_case(inp,case,seq,runner_factory=fail_product,capture=lambda:deepcopy(host))
    results['failed_product_prefix']={'status':report['status'],'reason':report.get('reason'),'attempts':len(report['attempts'])}
    try:
        rebuilt=wider.validate_case(report,inp,seq,host_environment=host)
        results['failed_product_prefix']['reconstructed']=True
    except Exception as e:results['failed_product_prefix'].update(reconstructed=False,validation_error=str(e))
print(json.dumps(results),flush=True)
with pytest.MonkeyPatch.context() as patch:
    root=base/'resource';root.mkdir()
    ctx=fixture_context(root,patch)
    wider,inp,case,seq,clock,factory,runners,host=ctx
    patch.setattr(preflight,'capture_host_environment',lambda:deepcopy(host))
    class SlowPreparation:
        def check_idle(self):
            clock.value+=14400_000_000_000
            return {}
    calls=[]
    def no_spawn(*args,**kwargs):
        calls.append('unexpected native spawn')
        raise AssertionError('must not launch')
    report=wider.execute_case(inp,case,seq,runner_factory=lambda store:ServerMeasurementRunner(store,process_factory=no_spawn,memory_sampler=SlowPreparation()),capture=lambda:deepcopy(host))
    results['resource_at_actual_runner_spawn']={'status':report['status'],'reason':report.get('reason'),'attempt_status':report['attempts'][0]['status'],'native_calls':len(calls)}
print(json.dumps(results),flush=True)
(base/'results.json').write_text(json.dumps(results,indent=2))
print('REPRO_ROOT='+str(base.resolve()),flush=True)

