"""Read-only live/registration comparison after the zero-start preflight stop."""
from dataclasses import replace
import json
from pathlib import Path
from expertflow.compiler.preflight import capture_host_environment
from expertflow.compiler.plan import CandidatePlan,RuntimeSettings
from expertflow.compiler.schema import canonical_payload,canonical_sha256
from expertflow.compiler.stock_eligibility import EligibilityRegistry
from expertflow.compiler.stock_search import scheduling_space,screening_schedule
from scripts.benchmark_compiler_stock_coverage import load_case_inputs

registration=json.loads(Path('configs/compiler/stock-coverage-20261005.json').read_text())
case=registration['cases'][2]
inputs=load_case_inputs(case,registration)
host=canonical_payload(capture_host_environment())
proof=EligibilityRegistry.with_builtins().attest(inputs,host,registration['source_repository'])
workload=replace(inputs.workload,threads=8,cuda_graphs='on')
identities=replace(inputs.identities(inputs.stock),workload=workload,workload_sha256=canonical_sha256(workload))
default=CandidatePlan(identities,RuntimeSettings(99,proof.get('baseline_cpu_moe',True)))
candidates=scheduling_space(default,host).candidates
expected={'model_artifact':canonical_payload(inputs.model.identity),'model_ir_sha256':canonical_sha256(inputs.model),
    'workload_sha256':canonical_sha256(workload),'runtime_sha256':inputs.stock.sha256,'provider_id':proof['provider_id'],
    'fixed_settings':canonical_payload(default.settings),'default_id':default.candidate_id,
    'candidate_ids':[c.candidate_id for c in candidates],
    'screening_schedule':canonical_payload(screening_schedule(c.candidate_id for c in candidates))}
differences={key:{'registered':case.get(key),'live':value} for key,value in expected.items() if canonical_payload(case.get(key))!=value}
record={'case_id':case['case_id'],'differences':differences,'eligibility':proof,'native_calls':0,
    'scope':'Diagnostic input re-read only; original sequence remains closed, zero native starts.'}
Path('.superpowers/sdd/2026-10-05-wider-stock-collector/preflight-scope-diagnosis.json').write_text(
    json.dumps(record,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(record))
from expertflow.stock.wider import scope_case
normalized=replace(inputs,model=replace(inputs.model,identity=replace(inputs.model.identity,
    path=Path(inputs.model.identity.path).resolve().as_posix())))
scope_case(normalized,case,{'source_repository':registration['source_repository'],
    'default_source_proof':registration['default_source_proof']},host)
assert Path(normalized.model.identity.path).samefile(inputs.model.identity.path)
proof_record={'status':'PASS','only_model_path_changed':replace(normalized.model,
    identity=inputs.model.identity)==inputs.model,'same_physical_file':True,
    'raw_weight_sha256':inputs.model.identity.sha256,
    'registered_model_ir_sha256':case['model_ir_sha256'],
    'normalized_model_ir_sha256':canonical_sha256(normalized.model),
    'all_registered_scope_and_candidate_fields_match':True,'native_calls':0}
Path('.superpowers/sdd/2026-10-05-wider-stock-collector/path-normalization-proof.json').write_text(
    json.dumps(proof_record,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(proof_record))
