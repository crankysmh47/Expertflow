"""Cheap prerequisites only; full weight identity loads belong to collection."""
import hashlib
import json
from pathlib import Path
import runpy
import subprocess
import time
from expertflow.compiler.preflight import capture_host_environment
from expertflow.compiler.schema import canonical_payload
from expertflow.stock.coverage import verify_registration

root=Path.cwd().resolve()
workspace=root/'.superpowers/sdd/2026-10-05-wider-stock-collector'
integrity=runpy.run_path('docs/evidence/stock-cli-20261005/validate_live.py')['integrity']
expected,starts,digest=integrity()
registration_path=root/'configs/compiler/stock-coverage-20261005.json'
registration=json.loads(registration_path.read_text())
verify_registration(registration,root)
host=canonical_payload(capture_host_environment())
assert host==registration['host_environment']
assert registration['registration_sha256']=='0376ac4d7c5e146bc594f5c22a4b1be803b446ced4c3d9d04a4cb0737af55603'
parent=Path(registration['cases'][0]['planned_root']).parent
assert not parent.exists() and all(not Path(c['planned_root']).exists() for c in registration['cases'])
before=time.perf_counter()
command=[str(root/'.venv/Scripts/expertflow.exe'),'stock','coverage','inspect']
check=subprocess.run(command,capture_output=True,check=True)
inspected=json.loads(check.stdout)
assert inspected['status']=='REGISTERED-NOT-RUN' and inspected['native_calls']==0
(workspace/'preflight-inspect.log').write_bytes(check.stdout)
record={'status':'PASS','host_matches_registration':True,'registration_sha256':registration['registration_sha256'],
    'registration_file_sha256':hashlib.sha256(registration_path.read_bytes()).hexdigest(),
    'sequence_root_unused':str(parent),'original_frozen_files':len(expected['frozen_files']),
    'original_history_pins':len(expected['historical_files']),'original_native_starts':len(starts),
    'original_report_sha256':digest,'inspection_wall_seconds':time.perf_counter()-before,
    'full_weight_hashes_verified':False,'new_native_calls':0}
(workspace/'preflight-small.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(record))
