# SDD ledger - plan: docs/superpowers/plans/2026-10-05-wider-stock-collector.md

Base: 5da6786, ef-v2.
Ruling: Work in place on the active branch per established user preference; preserve unrelated files. Cost if wrong: implementation changes are on ef-v2, reversible by task commits.
Ruling: Existing registered specification and explicit proceed authorization cover this implementation and execution; no redundant approval cycle. Cost if wrong: bounded native budget may be spent.
Pre-flight: Task 1 produces execute_case/validate_case and paced journal consumed by Task 2; exact registered roots and source freeze belong to the outer manifest. Task 3 consumes only reviewed committed source and does not alter frozen registration.

Task 1: initial RED: missing wider module (5 failed,9 errors). Initial GREEN attempt:13 passed,1 fixture commit-binding error; corrected fixture to the real Git source commit.
Task 2: initial RED: five missing-driver/routing failures. Focused attempt:51 passed,1 fake report missing manifest; corrected test fixture.
Timing control: owned-spawn budget test failed DID NOT RAISE before guarded process_factory hook; then6 focused controls passed.
Sequence control: four neutral cases collected344 fake native records, but validation exposed two reconstruction end timestamps; corrected elapsed calculation to the recorded finish timestamp.
Package source control: missing matching-package guard observed RED before implementation.
Ruling: Mutable implementation checklist is excluded from measured scientific source map; the immutable registration/specification, all executing code, tests and independent auditor are included. Cost if wrong: planning-only text is not bound to native launch hashes.

Pre-review full focused:62 passed,1 raw-auditor fixture missing paired_schedule (real registration already has it); fixture corrected. Public CLI reader-pool control observed AttributeError RED, then37 current focused controls passed after covering all wider aliases and avoiding nested pools.
Implementation candidate ready for independent review; full-suite and complete raw-auditor fixture verification remain pending. No native collection authorized by a missing review marker; source guard refuses it.

Final review: five Important findings confirmed; resource classification regraded to Important because the registered method requires distinct resource stop reasons. All are covered by the one fix pass. Fourteen new regression cases were RED against 6a0eed4. After implementation, the first/middle/last product failure, prelaunch resource prefix, chronology, runtime drift, installed source and public failed-owner controls passed; three newly added independent-auditor controls exposed a fixture checksum bug, corrected before final suite. Twelve fast guards then passed. No deferred minors.
Candidate full suite:866 passed,7 expected historical-source skips,1416.77s. Final suite pending. Applicable pinned native source checks:6 passed. Rebuilt installed wheel:7 smoke/source-matching checks passed, zero native calls.
Preflight: registered host matches; original41 frozen files/six history pins/148 starts and report SHA unchanged; all wider roots unused. Full weight verification belongs to all-input loading before launch.

Precollection prerequisite discovered after 961ab50: runtime-stock.json retains historically pinned CRLF bytes while Git stores equivalent LF text. No native root or call was created. New attestation control RED for CRLF, then15 fast controls GREEN after allowing only declared LF-text CRLF equivalence, with exact raw manifest digest and content-edit rejection. Freeze .gitattributes as an executing attestation input.
Ruling: accept only declared Git LF normalization during commit attestation while preserving raw frozen input bytes and source-map hashes. Cost if wrong: commit-to-worktree byte equivalence is limited to line endings; arbitrary content changes still fail and live raw digests remain authoritative.
Daemon interruption: initial latest full-suite supervisor vanished with an empty log and no surviving test/native process. Restarted only that unfinished check under hidden persistent supervisor PID15096 at2026-10-06T03:42:08Z. New registered native wrapper is source-bound; no native collection has started.
Ruling: use logged hidden supervisors for long verification/collection so a session restart can recover owned job state. Cost if wrong: background process ownership must be checked from saved PID/time, reports and artifacts before any further launch.

## Zero-start preflight correction

- The live preflight at commit337615a stopped before any freeze or native call: IDENTITY-STOP, zero attempts/starts,23.391s collector and23.774386s launcher wall. Its one-file root, original source snapshot, supervisor and log are preserved separately. Independent zero-start evidence audit: PASS.
- Granite live loading fully verified the registered weights/runtime, but its Windows path spelling differed from metadata inspection. Path-only normalization after the unchanged live loader restores registered IR/default/candidates/schedules. Native-spelling regression RED failed, both native/POSIX GREEN controls passed.
- Fresh read-only full live scope verification: all4 cases PASS, zero calls,20.0823009s. Seven installed-wheel checks PASS; current host/registration/unused roots and original41source/sixhistory/148starts integrity PASS.
- Ruling: preserve the audited zero-start root and permit a fresh precollection attempt after full verification and committed freeze under the unchanged registration — the resolved prerequisite mismatch spent no native budget and produced no samples — cost if wrong: two separately identified preflight attempts and retained overhead. No native retry, resume, discard or scientific budget reuse is permitted. See precollection-decision.md.
- Final normalization full suite running under hidden supervisor PID18264, started2026-10-06T04:20:04Z. No wider native model has been launched.

Final correction suite completed:891 passed,7 expected skips,1607.12s,exit0. Seven installed-wheel checks PASS; zero native calls.

Task 3: complete (native source78ad5f0; public coverage validate PASS exit0,93.399970s; independent raw audit PASS344 records; zero extra calls; four NO-UTILITY-GAIN outcomes). Keep active ef-v2 in place; no integration requested.
