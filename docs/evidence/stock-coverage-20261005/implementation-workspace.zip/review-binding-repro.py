import sys,json,uuid
from pathlib import Path
from dataclasses import replace
from copy import deepcopy
import pytest
sys.path[:0]=[str(Path.cwd()),str(Path('tests').resolve())]
from test_stock_wider import fixture_context
from expertflow.compiler.runner import ServerMeasurementRunner,RuntimeBinding
from expertflow.compiler.evidence import EvidenceStore
from expertflow.compiler.plan import CandidatePlan,RuntimeSettings
from expertflow.compiler.schema import ArtifactIdentity
from expertflow.compiler.preflight import file_sha256
from expertflow.compiler import preflight
from expertflow.stock.wider_audit import audit_attempts
base=Path('.superpowers/sdd/2026-10-05-wider-stock-collector')/('review-repro-binding-'+uuid.uuid4().hex[:8]);base.mkdir()
results={}
with pytest.MonkeyPatch.context() as patch:
    ctx=fixture_context(base,patch)
    wider,inp,case,seq,clock,factory,runners,host=ctx
    bindir=base/'binaries';bindir.mkdir()
    server=bindir/'llama-server.exe';server.write_bytes(b'server')
    cli=bindir/'llama-cli.exe';cli.write_bytes(b'cli')
    cuda=base/'cuda.dll';cuda.write_bytes(b'cuda')
    identity=lambda p:ArtifactIdentity(str(p.resolve()),p.stat().st_size,file_sha256(p))
    manifest={'binaries':{'llama-server.exe':file_sha256(server),'llama-cli.exe':file_sha256(cli)},'dependencies':{},'cuda_runtime_sha256':file_sha256(cuda),'patches':[]}
    binding=RuntimeBinding(identity(server),json.dumps(manifest),(),identity(cuda))
    binding.verify_manifest_bindings()
    inp=replace(inp,stock=binding)
    candidate=CandidatePlan(inp.identities(binding),RuntimeSettings(99,True))
    root=Path(case['planned_root']);root.mkdir()
    report={'manifest':{'experiment_root':str(root.resolve()),'source_files':wider.sources(),'host_environment':host,'case_started_monotonic_ns':clock.now(),'sequence_started_monotonic_ns':clock.now(),'input_load_seconds':0,'manifest_sha256':'a'*64},'attempts':[]}
    calls=[]
    def no_native(*args,**kwargs):
        calls.append('process_factory_called')
        raise RuntimeError('review sentinel; no native process launched')
    def drift(seconds):
        clock.sleep(seconds)
        cli.write_bytes(b'CHANGED CLI')
    patch.setattr(wider.time,'sleep',drift)
    patch.setattr(preflight,'capture_host_environment',lambda:deepcopy(host))
    runner=wider.PacedRunner(ServerMeasurementRunner(EvidenceStore(root/'utility.sqlite3'),process_factory=no_native),report,lambda:deepcopy(host))
    outcome=runner.run_once(candidate,inp.model,binding,output_dir=root/'raw/one',stage='fixture',measured=True)
    results['runtime_cli_drift_during_wait']={'spawn_factory_calls':len(calls),'status':outcome.status}
root=(base/'failed-native').resolve();root.mkdir();output=root/'raw/one';output.mkdir(parents=True)
start={'pid':1,'creation_time_100ns':2,'creation_source':'GetProcessTimes','started_monotonic_ns':31_000_000_000}
(output/'run-start.json').write_text(json.dumps(start));(output/'process.json').write_text(json.dumps({'pid':999,'cleanup':True}))
report={'manifest':{'experiment_root':str(root),'frozen_monotonic_ns':1,'case_started_monotonic_ns':1,'sequence_started_monotonic_ns':1,'input_load_seconds':0},'attempts':[{'output_dir':str(output),'database':str(root/'utility.sqlite3'),'wait_started_monotonic_ns':1_000_000_000,'wait_finished_monotonic_ns':31_000_000_000,'wait_elapsed_ns':30_000_000_000,'wait_seconds':30,'finished_monotonic_ns':32_000_000_000,'native_started':True,'process_identity':start,'status':'environment_blocked'}]}
results['failed_native_missing_launch_wrong_cleanup_owner']={'accepted_owners':list(audit_attempts(report))}
(base/'results.json').write_text(json.dumps(results,indent=2));print(json.dumps(results));print('REPRO_ROOT='+str(base.resolve()))
