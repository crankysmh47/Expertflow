"""Preserve exact reviewed raw bytes, including pinned CRLF inputs."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

from expertflow.stock.wider import sources
from scripts.benchmark_compiler_stock_coverage import require_committed_sources

root=Path.cwd().resolve()
destination=root/'docs/evidence/stock-coverage-20261005'
archive=destination/'corrected-source-snapshot.zip'
if archive.exists():raise ValueError('source archive exists; do not overwrite')
source_files=sources()
require_committed_sources(source_files)
entries=[]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as output:
    for filename,digest in sorted(source_files.items()):
        path=Path(filename)
        data=path.read_bytes()
        if hashlib.sha256(data).hexdigest()!=digest:raise ValueError('source changed during snapshot: '+filename)
        relative=path.relative_to(root).as_posix()
        info=zipfile.ZipInfo(relative,date_time=(2026,10,6,0,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED
        output.writestr(info,data)
        entries.append({'original_path':filename,'member':relative,'sha256':digest,'size_bytes':len(data)})
with zipfile.ZipFile(archive) as saved:
    assert all(hashlib.sha256(saved.read(e['member'])).hexdigest()==e['sha256'] for e in entries)
assert sources()==source_files
record={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'created_at_utc':datetime.now(timezone.utc).isoformat(),'source_files':source_files,
    'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'entries':entries,
    'scope':'Exact raw reviewed source/input bytes; native weights/artifacts retain their registered absolute paths.'}
(destination/'corrected-source-snapshot.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'status':'PASS','frozen_raw_files':len(entries),'source_commit':record['source_commit']}))
