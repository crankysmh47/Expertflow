"""Read-only job/attempt inventory; never launches or validates a model."""
import json
from pathlib import Path
import time

workspace=Path('.superpowers/sdd/2026-10-05-wider-stock-collector')
root=Path('C:/models/expertflow/runs/compiler-stock-coverage-20261005')
record={'job':json.loads((workspace/'native-job.json').read_text())}
path=root/'report.json'
if path.is_file():
    outer=json.loads(path.read_text())
    record.update(sequence=outer['status'],reason=outer.get('reason'),last_loaded_case=outer.get('last_loaded_case'),cases=[])
    registration=json.loads(Path('configs/compiler/stock-coverage-20261005.json').read_text())
    for case in registration['cases']:
        directory=Path(case['planned_root'])
        report_path=directory/'report.json'
        if not report_path.is_file():
            record['cases'].append({'case':case['case_id'],'status':'NOT-RUN'})
            continue
        report=json.loads(report_path.read_text())
        attempts=report.get('attempts',[])
        record['cases'].append({'case':case['case_id'],'status':report['status'],'reason':report.get('reason'),
            'rows':len(report.get('rows',[])),'attempts':len(attempts),
            'native_starts':len(list(directory.rglob('run-start.json'))),
            'last_output':Path(attempts[-1]['output_dir']).name if attempts else None,
            'last_phase':attempts[-1]['status'] if attempts else None,
            'case_elapsed_seconds':round((time.monotonic_ns()-report['manifest']['case_started_monotonic_ns'])/1e9+
                report['manifest']['input_load_seconds'],1) if report['status']=='RUNNING' else report.get('collection_wall_seconds')})
    record['native_starts']=len(list(root.rglob('run-start.json')))
else:record['sequence']='NO-REPORT'
print(json.dumps(record,separators=(',',':')))
