"""Read-only full input/scope check; no experiment root or native process."""
import json
from pathlib import Path
import time
from expertflow.compiler.preflight import capture_host_environment
from expertflow.compiler.schema import canonical_payload
from expertflow.stock.wider import scope_case
from scripts.benchmark_compiler_stock_coverage import load_case_inputs

registration=json.loads(Path('configs/compiler/stock-coverage-20261005.json').read_text())
host=canonical_payload(capture_host_environment())
assert host==registration['host_environment']
scope={'source_repository':registration['source_repository'],'default_source_proof':registration['default_source_proof']}
before=time.perf_counter()
cases=[]
for case in registration['cases']:
    inputs=load_case_inputs(case,registration)
    proof,default,candidates=scope_case(inputs,case,scope,host)
    assert not Path(case['planned_root']).exists()
    cases.append({'case_id':case['case_id'],'registered_inputs_and_grid_match':True,
        'live_weight_hash_verified':True,'provider_id':proof['provider_id'],'default_id':default.candidate_id,
        'candidate_count':len(candidates)})
record={'status':'PASS','native_calls':0,'wall_seconds':time.perf_counter()-before,'cases':cases,
    'scope':'Diagnostic full input identity/scope check only; no collected utility evidence or case roots.'}
Path('.superpowers/sdd/2026-10-05-wider-stock-collector/live-scope-check.json').write_text(
    json.dumps(record,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(record))
