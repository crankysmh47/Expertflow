"""Archive terminal reports and derive compact descriptive costs."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil

base = Path('C:/models/expertflow/runs/compiler-stock-coverage-20261005')
workspace = Path('.superpowers/sdd/2026-10-05-wider-stock-collector')
destination = Path('docs/evidence/stock-coverage-20261005')
report = json.loads((base / 'report.json').read_text())
for source, name in ((base/'report.json', 'native-sequence-report.json'),
                     (base/'frozen-manifest.json', 'frozen-sequence-manifest.json'),
                     (workspace/'native-job.json', 'native-supervisor.json'),
                     (workspace/'native-collection.log', 'native-collection.log'),
                     (workspace/'validation-job.json', 'public-validation-supervisor.json'),
                     (workspace/'public-validation.log', 'public-validation.log'),
                     (workspace/'public-validation-stderr.log', 'public-validation-stderr.log'),
                     (workspace/'native-verification.json', 'native-verification.json'),
                     (workspace/'validate_final.py', 'validate_final.py')):
    shutil.copyfile(source, destination/name)
cases = []
for case in report['cases']:
    raw = json.loads((base/case['case_id']/'report.json').read_text())
    candidates = raw['manifest']['candidates']
    stats = case['statistics']
    item = {k: case[k] for k in ('case_id','status','attempts','native_processes','selected_default',
             'input_load_seconds','collection_wall_seconds','reconstruction_wall_seconds','case_wall_seconds',
             'wait_seconds','native_phase_seconds','phase_costs','peak_owned_bytes','minimum_device_free_bytes')}
    for role in ('automatic','manual'):
        selected = candidates[raw[role+'_id']]
        item[role+'_selection'] = {'candidate_id': raw[role+'_id'],
            'threads': selected['identities']['workload']['threads'],
            'cuda_graphs': selected['settings']['cuda_graphs'], 'evaluations': stats[role+'_evaluations']}
    item['defaults_comparison'] = {k: stats['gain'][k] for k in ('geometric_change_pct','ci95_pct','direct_mean_tps','sealed_mean_tps','direct_cv_pct','sealed_cv_pct')}
    item['manual_comparison'] = {k: stats['manual_equivalence'][k] for k in ('geometric_change_pct','ci90_pct','direct_cv_pct','sealed_cv_pct')}
    item['utility_gain_established'] = case['utility_gain_established']
    item['product_calls'] = item['consumer_calls'] = 0
    cases.append(item)
summary = {'status': report['status'], 'source_commit': report['manifest']['source_commit'],
    'created_at_utc': datetime.now(timezone.utc).isoformat(), 'native_report_sha256': hashlib.sha256((base/'report.json').read_bytes()).hexdigest(),
    'native_attempts': report['attempts'], 'native_starts': report['native_processes'],
    'maximum_native_processes': 428, 'unused_conditional_budget': 84,
    'sequence_wall_seconds': report['sequence_wall_seconds'],
    'supervisor_wall_seconds': (datetime.fromisoformat(json.loads((workspace/'native-job.json').read_text())['finished_at_utc'])-
                               datetime.fromisoformat(json.loads((workspace/'native-job.json').read_text())['started_at_utc'])).total_seconds(),
    'total_wait_seconds': sum(c['wait_seconds'] for c in cases),
    'total_native_phase_seconds': sum(c['native_phase_seconds'] for c in cases),
    'total_input_load_seconds': sum(c['input_load_seconds'] for c in cases),
    'total_case_reconstruction_seconds': sum(c['reconstruction_wall_seconds'] for c in cases),
    'cases': cases, 'limits': 'Four registered existing prose/code cases, one host, six thread/graph candidates; no product, consumer, family-wide utility, global-optimum, or serving claim.'}
(destination/'result-summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True)+'\n', encoding='utf-8', newline='\n')
print(json.dumps({k:v for k,v in summary.items() if k != 'cases'}))
print(json.dumps([{'case':c['case_id'],'automatic':c['automatic_selection'],'manual':c['manual_selection']} for c in cases]))
