"""Read-only installed-wheel smoke checks; no model launch."""
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

root=Path.cwd().resolve()
workspace=root/'.superpowers/sdd/2026-10-05-wider-stock-collector'
python=workspace/'wheel-env/Scripts/python.exe'
cli=python.with_name('expertflow.exe')
checks=[]
with tempfile.TemporaryDirectory(prefix='expertflow-wider-wheel-') as cwd:
    def run(args,expected=0):
        command=[str(a) for a in args]
        result=subprocess.run(command,cwd=cwd,capture_output=True,text=True)
        if result.returncode!=expected:raise AssertionError(result.stdout+'\n'+result.stderr)
        checks.append({'command':command,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
        return result.stdout
    assert 'site-packages' in run([python,'-c','import expertflow.stock.cli; print(expertflow.stock.cli.__file__)'])
    assert 'stock' in run([cli,'--help'])
    missing=json.loads(run([cli,'stock','coverage','run'],3))
    assert missing['status']=='ENVIRONMENT-BLOCKED'
    for action in ('run','validate'):
        assert '--registration' in run([cli,'stock','--project',root,'coverage',action,'--help'])
    inspected=json.loads(run([cli,'stock','--project',root,'coverage','inspect']))
    assert inspected['status']=='REGISTERED-NOT-RUN' and inspected['native_calls']==0
    code="import os,runpy; os.chdir("+repr(str(root))+"); runpy.run_path('scripts/benchmark_compiler_stock_coverage.py')['require_matching_package']()"
    run([python,'-c',code])
wheel=workspace/'dist/expertflow_local-0.1.0-py3-none-any.whl'
result={'status':'PASS','checks':checks,'wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),
        'native_calls':0,'scope':'Installed source matching, public routing/help and metadata-only registration inspection.'}
(workspace/'packaging-final.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'status':'PASS','checks':len(checks),'native_calls':0}))
