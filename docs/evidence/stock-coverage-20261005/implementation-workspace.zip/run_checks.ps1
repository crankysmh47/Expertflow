$ErrorActionPreference='Stop'
$widerRepo='C:\sem4\expertflow'
$widerWorkspace=Join-Path $widerRepo '.superpowers\sdd\2026-10-05-wider-stock-collector'
Set-Location -LiteralPath $widerRepo
$widerJob=[ordered]@{status='RUNNING';pid=$PID;started_at_utc=[DateTime]::UtcNow.ToString('o');command='uv run pytest -q';exit_code=$null}
$widerJob | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $widerWorkspace 'full-suite-job.json') -Encoding utf8
try {
    & uv run pytest -q *> (Join-Path $widerWorkspace 'full-suite-freeze.log')
    $widerJob.exit_code=$LASTEXITCODE
    $widerJob.status='COMPLETED'
} catch {
    $widerJob.status='SUPERVISOR-FAILED'
    $widerJob.reason=$_.Exception.Message
} finally {
    $widerJob.finished_at_utc=[DateTime]::UtcNow.ToString('o')
    $widerJob | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $widerWorkspace 'full-suite-job.json') -Encoding utf8
}
