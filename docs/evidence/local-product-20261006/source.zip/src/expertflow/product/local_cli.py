"""Portable public local-model workflow; independent of research artifacts."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys

from expertflow.doctor import collect_doctor_report
from .paths import data_root
from .runtime import inspect_runtime, download_archive, install_archive


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="expertflow local", description="Set up, measure and run local GGUF models on your hardware.")
    sub = parser.add_subparsers(dest="action", required=True)
    doctor = sub.add_parser("doctor", help="Inspect hardware and optional runtime without loading a model.")
    doctor.add_argument("--runtime", type=Path)
    doctor.add_argument("--model", type=Path)
    doctor.add_argument("--dll-dir", type=Path, action="append", default=[])
    doctor.add_argument("--json", action="store_true")
    install = sub.add_parser("install-runtime", help="Explicitly download a checksum-verified llama.cpp archive.")
    install.add_argument("--url", required=True)
    install.add_argument("--sha256", required=True)
    install.add_argument("--destination", type=Path, required=True)
    install.add_argument("--json", action="store_true")
    setup = sub.add_parser("setup", help="Create a portable profile and verify a real baseline load.")
    setup.add_argument("--model", type=Path, required=True)
    setup.add_argument("--runtime", type=Path, required=True)
    setup.add_argument("--context", type=int, default=4096)
    setup.add_argument("--gpu-layers", type=int)
    setup.add_argument("--threads", type=int)
    setup.add_argument("--cpu-moe", action="store_true")
    setup.add_argument("--dll-dir", type=Path, action="append", default=[])
    setup.add_argument("--name")
    setup.add_argument("--output", type=Path)
    setup.add_argument("--no-probe", action="store_true", help="Save an explicitly unverified profile without a model process.")
    setup.add_argument("--health-timeout", type=int, default=180)
    setup.add_argument("--json", action="store_true")
    profiles = sub.add_parser("profiles", help="List, show or remove profiles; never delete model weights.")
    profiles.add_argument("operation", choices=["list", "show", "remove"])
    profiles.add_argument("--profile", type=Path)
    profiles.add_argument("--json", action="store_true")
    return parser


def emit(report: dict, *, json_output: bool) -> None:
    if json_output:
        print(json.dumps(report, indent=2, ensure_ascii=True))
        return
    print(report["status"])
    if report.get("reason"):
        print(report["reason"])
    if report.get("hardware"):
        hardware = report["hardware"]
        print(f"RAM: {hardware['system_ram_bytes'] / 1024**3:.1f} GiB")
        for gpu in hardware["gpus"]:
            print(f"GPU: {gpu['name']} — {gpu['memory_free_mib']} MiB free / {gpu['memory_total_mib']} MiB")
        if hardware["gpu_error"]:
            print(f"GPU detection: {hardware['gpu_error']}")
    if report.get("runtime"):
        print(f"Runtime: {report['runtime']['version']}")
    if report.get("next_action"):
        print(report["next_action"])
    if report.get("profile_path"):
        print(f"Profile: {report['profile_path']}")
    if report.get("profiles"):
        for item in report["profiles"]:
            print(f"{item['name']}: {item['status']} — {item['path']}")


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.action == "doctor":
            report = {"status": "INSPECTED", "hardware": collect_doctor_report(Path.cwd()),
                      "state_directory": str(data_root()),
                      "next_action": "Use local setup with a GGUF and the runtime bin directory."}
            if args.runtime:
                report["runtime"] = inspect_runtime(args.runtime, dll_dirs=args.dll_dir)
            if args.model:
                if not args.model.is_file():
                    raise ValueError("Model file is missing; correct --model.")
                report["model"] = {"path": str(args.model.resolve()), "size_bytes": args.model.stat().st_size}
        elif args.action == "install-runtime":
            archive = args.destination.parent / (args.destination.name + ".download")
            download_archive(args.url, archive, args.sha256)
            directory = install_archive(archive, args.destination)
            report = {"status": "INSTALLED", "directory": str(directory),
                      "next_action": f"Run local doctor --runtime \"{directory}\" to check dependencies."}
        elif args.action == "setup":
            from .setup import setup_profile
            import uuid
            output = args.output or data_root() / "profiles" / (uuid.uuid4().hex + ".json")
            profile = setup_profile(args.model, args.runtime, output, context=args.context,
                gpu_layers=args.gpu_layers, threads=args.threads, cpu_moe=args.cpu_moe,
                dll_dirs=args.dll_dir, name=args.name, probe=not args.no_probe,
                health_timeout=args.health_timeout)
            report = {"status": profile["status"], "profile_path": str(output.resolve()),
                "memory_estimate": profile["memory_estimate"], "load_verified": profile["load_verified"],
                "next_action": f'Run: expertflow local run --profile "{output.resolve()}"'}
        elif args.action == "profiles":
            from .profiles import load_profile
            if args.operation == "list":
                items = []
                for path in sorted((data_root() / "profiles").glob("*.json")):
                    try:
                        p = load_profile(path)
                        items.append({"name": p["name"], "status": p["status"], "path": str(path)})
                    except ValueError:
                        items.append({"name": path.stem, "status": "INVALID-PROFILE", "path": str(path)})
                report = {"status": "INSPECTED", "profiles": items}
            else:
                if args.profile is None:
                    raise ValueError("--profile is required for show/remove.")
                p = load_profile(args.profile)
                if args.operation == "remove":
                    args.profile.unlink()
                    report = {"status": "REMOVED", "reason": "Profile removed; model and runtime files retained."}
                else:
                    report = {"status": p["status"], "profile": p, "profile_path": str(args.profile)}
        emit(report, json_output=args.json)
        return 0
    except (ValueError, OSError) as error:
        emit({"status": "UNSUPPORTED", "reason": str(error),
              "next_action": "Correct the reported input/dependency and retry. No model was started."}, json_output=args.json)
        return 2


if __name__ == "__main__":
    sys.exit(main())
