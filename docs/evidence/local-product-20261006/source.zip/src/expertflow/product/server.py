"""Loopback llama-server sessions, health, completion and streaming chat."""
from __future__ import annotations
import json
from pathlib import Path
import socket
import time
from urllib.request import Request, build_opener, ProxyHandler
from urllib.error import URLError

from .profiles import verify_profile
from .runtime import runtime_environment
from .session import OwnedProcess, build_command


class ServerSession:
    def __init__(self, profile: dict, *, log_dir: Path, port=0, health_timeout=180):
        self.profile, self.log_dir, self.port = profile, log_dir, port
        self.health_timeout = health_timeout
        self.child = None
        self.props = None
        self.opener = build_opener(ProxyHandler({}))

    def __enter__(self):
        if type(self.port) is not int or not 0 <= self.port <= 65535:
            raise ValueError("Port must be 0 (automatic) or 1–65535.")
        with socket.socket() as probe:
            try:
                probe.bind(("127.0.0.1", self.port))
                self.port = probe.getsockname()[1]
            except OSError as error:
                raise ValueError(f"Port {self.port} is occupied; choose another --port. No existing process was stopped.") from error
        verify_profile(self.profile)
        self.url = f"http://127.0.0.1:{self.port}"
        self.child = OwnedProcess(build_command(self.profile, port=self.port),
                                  env=runtime_environment(self.profile["runtime"]),
                                  log_path=self.log_dir / "server.log")
        self.child.__enter__()
        deadline = time.monotonic() + self.health_timeout
        try:
            while time.monotonic() < deadline:
                if self.child.process.poll() is not None:
                    raise ValueError(f"Model load failed (exit {self.child.process.returncode}); inspect {self.log_dir / 'server.log'}. Check architecture, RAM/VRAM, context and runtime dependencies.")
                try:
                    if self.request("/health", timeout=2).get("status") == "ok":
                        self.props = self.request("/props", timeout=5)
                        actual = self.props.get("default_generation_settings", {}).get("n_ctx")
                        if actual is not None and actual < self.profile["settings"]["context"]:
                            raise ValueError("Runtime reduced the requested context; choose an explicit smaller profile.")
                        return self
                except (URLError, TimeoutError, OSError):
                    pass
                time.sleep(0.1)
            raise ValueError(f"Model health timed out; inspect {self.log_dir / 'server.log'}. Reduce context explicitly or check runtime dependencies.")
        except BaseException:
            self.child.__exit__()
            raise

    def __exit__(self, *exc):
        if self.child:
            self.child.__exit__(*exc)

    def request(self, route: str, payload=None, *, timeout=120) -> dict:
        request = Request(self.url + route, data=json.dumps(payload).encode() if payload is not None else None,
                          headers={"Content-Type": "application/json"})
        with self.opener.open(request, timeout=timeout) as response:
            data = response.read(32 * 1024**2 + 1)
        if len(data) > 32 * 1024**2:
            raise ValueError("Runtime response exceeded 32 MiB.")
        result = json.loads(data)
        if not isinstance(result, dict) or result.get("error"):
            raise ValueError(f"Runtime request failed: {result.get('error') if isinstance(result, dict) else 'invalid response'}")
        return result

    def complete(self, prompt: str, *, predict=128, timeout=120) -> dict:
        if not isinstance(prompt, str) or not prompt or len(prompt.encode()) > 1024 * 1024:
            raise ValueError("Prompt must contain 1 byte to 1 MiB of text.")
        if type(predict) is not int or not 1 <= predict <= 65536:
            raise ValueError("Predict tokens must be between 1 and 65536.")
        start = time.monotonic()
        result = self.request("/completion", {"prompt": prompt, "n_predict": predict, "seed": 42,
            "temperature": 0.0, "cache_prompt": False, "return_tokens": True,
            "ignore_eos": False, "stream": False}, timeout=timeout)
        result["wall_seconds"] = time.monotonic() - start
        return result

    def chat(self, messages: list[dict], *, predict=256, timeout=120):
        request = Request(self.url + "/v1/chat/completions", data=json.dumps({
            "messages": messages, "max_tokens": predict, "seed": 42,
            "temperature": 0.0, "stream": True}).encode(), headers={"Content-Type": "application/json"})
        with self.opener.open(request, timeout=timeout) as response:
            while True:
                line = response.readline(1024 * 1024 + 1)
                if not line:
                    break
                if len(line) > 1024 * 1024:
                    raise ValueError("Oversized streaming response.")
                if not line.startswith(b"data: "):
                    continue
                data = line[6:].strip()
                if data == b"[DONE]":
                    break
                event = json.loads(data)
                if event.get("error"):
                    raise ValueError(f"Runtime stream failed: {event['error']}")
                for choice in event.get("choices", []):
                    text = choice.get("delta", {}).get("content")
                    if text:
                        yield text
