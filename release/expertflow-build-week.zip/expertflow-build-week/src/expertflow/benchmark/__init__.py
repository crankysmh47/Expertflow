"""Reproducible performance benchmark helpers."""
