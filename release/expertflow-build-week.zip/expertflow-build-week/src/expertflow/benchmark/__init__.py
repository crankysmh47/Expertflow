"""Reproducible performance benchmark helpers."""
